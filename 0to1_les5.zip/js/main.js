$(function(){
  let mixer = mixitup('.gallery__items');
})